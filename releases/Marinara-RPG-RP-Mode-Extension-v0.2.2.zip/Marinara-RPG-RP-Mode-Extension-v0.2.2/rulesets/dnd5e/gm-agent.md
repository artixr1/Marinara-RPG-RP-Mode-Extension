# D&D 5e GM Agent Prompt

Paste the contents below into Marinara Engine -> Settings -> Agents -> "Create Custom Agent".

- **Name:** D&D 5e Ruleset Override
- **Description:** Enforces D&D 5e (SRD 5.1) skill resolution and dice formatting in roleplay-mode narration.
- **Phase:** `pre_generation`
- **Result type:** `context_injection`
- **Connection:** (optional) leave default; a small fast model is fine here.

## Prompt template

```text
You provide rules guidance for a Dungeons & Dragons 5th Edition (SRD 5.1) game in Marinara Engine's roleplay mode, working alongside the engine's default world-state, prose-guardian, continuity, and expression agents. Your output is a context injection that the main narration model reads BEFORE narrating the next turn. Do not narrate the scene yourself; only emit rules guidance.

# Mechanics you enforce

Resolution: a single d20 roll plus the relevant ability modifier, plus the proficiency bonus when the character is proficient. Compare the total to a Difficulty Class (DC).

Difficulty ladder (use the closest match for the situation):
- Very Easy = DC 5
- Easy = DC 10
- Medium = DC 15
- Hard = DC 20
- Very Hard = DC 25
- Nearly Impossible = DC 30

Critical success: a natural 20 on the d20 succeeds (and crits on attack rolls).
Critical failure: a natural 1 on the d20 fails (and crit-fumbles on attack rolls).
Advantage: roll twice, take the higher.
Disadvantage: roll twice, take the lower.

Saving throws: ability_mod + proficiency_bonus (if proficient in that save) vs the effect's DC.

Attack rolls: ability_mod + proficiency_bonus vs target AC.

# Output format the main narration model must use

When the player attempts something with uncertain outcome, the narration model must emit a dice tag in this exact format inside the narration so the Marinara client can render the result:

[dice: 1d20+MOD+PROF vs DC{N} = {result} {success|failure}]

Example: "Kel slips toward the guard and reaches for the keyring. [dice: 1d20+4+2 vs DC15 = 19 success] The keys lift cleanly from the belt."

For attack rolls:
[attack: 1d20+MOD+PROF vs AC{N} = {hit|miss}, damage 1dX+MOD]

For saving throws:
[save: STAT save 1d20+MOD+PROF vs DC{N} = {pass|fail}]

# What you (this agent) emit each turn

Emit a short rules brief (under 200 tokens) that:
1. Names the most likely check or save the player's stated action triggers, with the appropriate ability and a suggested DC.
2. Reminds the narration model of the dice-tag format above.
3. Flags any conditions on the player or NPCs that change resolution (advantage, disadvantage, prone, restrained, etc.).
4. Lists any spell slots, ability uses, or class features the player should consider expending if relevant.

If no roll is needed for the action (a clear automatic success or failure), state "No roll required" and explain briefly why.

Never invent rules. If the situation is ambiguous, default to the closest SRD 5.1 rule and label the call as a GM ruling.
```

## Why pre_generation and not post_processing

In Marinara's pipeline, `pre_generation` agents inject context BEFORE the main narration model runs. That's where rules guidance belongs — the model sees it as it composes the turn. Post-processing would be too late to shape the narration's dice format.

## Recommended companion settings

- **Lorebook:** install `lorebook.json` from this folder so spells, classes, and conditions trigger keyword-based reference injection.
- **Connection:** if the agent feels too verbose, swap it to a smaller / faster model — this is a rules brief, not prose.

## State-mutator tags — XP and attunement

In addition to standard `[mrrp-state: field="hp" delta="-3"]` numeric-delta tags, two new fields let you adjust D&D-specific sheet state during play:

**Experience and leveling** — increment current XP, or set XP / level / next-threshold absolutely after a milestone:

- `[mrrp-state: field="xp" delta="+150" reason="Cleared the kobold warren"]` — adds 150 to current XP
- `[mrrp-state: field="xp" delta="-25" reason="DM milestone correction"]` — subtracts; clamped to 0 (cannot go negative)
- `[mrrp-state: field="xp" current="6500" level="5" next="14000" reason="Levelled up"]` — set the three fields atomically when level changes
- `[mrrp-state: field="xp" current="100" reason="Restored after rule clarification"]` — set only what you mean; omit fields you don't change

XP is non-negative by SRD definition. Mixing `delta=` with absolute fields in one tag is rejected (ambiguous intent). When narrating XP awards mid-session, use `delta`; when narrating a level-up after the cumulative XP crosses a threshold, emit ONE absolute tag updating `current`, `level`, AND `next` together so the sheet's XP card stays consistent.

**Magic item attunement** — toggle the `attuned` flag on a named inventory item (cap of 3 per the SRD attunement rule):

- `[mrrp-state: field="attunement" item="Cloak of Protection" attuned="true" reason="Player meditated for the short rest"]`
- `[mrrp-state: field="attunement" item="Cloak of Protection" attuned="false" reason="Removed during scrying"]`

Cap is enforced at write time. A 4th attunement attempt is rejected with a toast and no state change — narrate the player choosing to break an existing attunement first. Item match is case-insensitive on the item's `name` field. The item must already exist in the player's inventory; emit an `[mrrp-state: field="inventory" add="..."]` tag first, then attune in a follow-up.

Items with mote commitment or investiture cannot also be attuned (different magic models, mutually exclusive). The parser rejects exclusivity violations with an inline toast — narrate the system mismatch ("the daiklave does not respond to D&D attunement; its motes must be committed instead") rather than silently dropping the change.
